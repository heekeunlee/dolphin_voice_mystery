#!/usr/bin/env python3
"""확정 원고(drafts/dolphin-said)를 조판 소스(book/src)로 옮긴다.

- 원고는 손대지 않는다. HTML 주석(작가·심사 메모)을 빼고 .qmd로 복사한다.
- 부속물은 인쇄용 부분만 남긴다(예: 「소리코지 사람들」은 'A. 쪽 문안'만).
- 다시 실행하면 src/를 통째로 새로 만든다. src/ 파일은 직접 고치지 말 것.
"""
import re, pathlib, shutil, os

ROOT = pathlib.Path(__file__).resolve().parents[2]
DRAFT = ROOT / "drafts" / "dolphin-said"
MATTER = DRAFT / "matter"
SRC = ROOT / "book" / "src"

def curly_single(t: str) -> str:
    """'…' 짝을 ‘…’로. 코드 블록과 인라인 코드는 건드리지 않는다(pandoc smart는 '단어'를 의 ' 를 아포스트로피로 오인)."""
    parts = re.split(r"(```.*?```|`[^`\n]*`)", t, flags=re.S)
    for i in range(0, len(parts), 2):
        parts[i] = re.sub(r"'([^'\n]+?)'", "\u2018\\1\u2019", parts[i])
    return "".join(parts)

def strip_comments(t: str) -> str:
    t = re.sub(r"<!--.*?-->", "", t, flags=re.S)
    t = re.sub(r"\n(?:\s*---\s*\n)+\s*$", "\n", t)   # 끝에 남은 구분선 제거
    t = curly_single(t)
    return t.rstrip() + "\n"

def write(name: str, text: str):
    (SRC / name).write_text(text, encoding="utf-8")

def chapters():
    for i in range(1, 18):
        t = strip_comments((DRAFT / f"ch{i:02d}-{os.environ.get('CH_SUFFIX', 'final')}.md").read_text(encoding="utf-8"))
        lines = t.split("\n")
        assert lines[0].startswith("# "), f"ch{i:02d}: 첫 줄이 장 제목이 아님"
        lines[0] = lines[0] + " {.chapter-title}"
        write(f"ch{i:02d}.qmd", "\n".join(lines))

def section(text: str, start: str, end_pat: str = r"\n## ") -> str:
    i = text.index(start) + len(start)
    m = re.search(end_pat, text[i:])
    return text[i:i + m.start()] if m else text[i:]

def tables_to_lines(md: str) -> str:
    """좁은 A5 폭에서 3단 표가 깨지므로, 교정쇄에서는 한 사람 한 줄로 푼다(디자이너가 그림 쪽으로 다시 짠다)."""
    out = []
    for line in md.split("\n"):
        if re.match(r"^\|\s*-", line):
            continue
        if line.startswith("|"):
            cells = [c.strip() for c in line.strip("|").split("|")]
            if cells[0] in ("이름", "지느러미"):
                continue
            if len(cells) == 3 and cells[0].startswith("**"):      # 이름 | 한 줄 | 소품
                out.append(f"{cells[0]} — {cells[1]} *({cells[2]})*\n")
            elif len(cells) == 3:                                  # 그림 | 이름 | 한 줄
                out.append(f"{cells[1]} — {cells[2]}\n")
            elif len(cells) == 2:                                  # 이름 | 하는 일
                out.append(f"**{cells[0]}** — {cells[1]}\n")
            continue
        out.append(line)
    return "\n".join(out)

def front():
    t = (MATTER / "front-01-소리코지-사람들.md").read_text(encoding="utf-8")
    body = section(t, "## A. 쪽 문안 (이 글자만 인쇄한다)")
    body = strip_comments(body)
    body = re.sub(r"\n---\s*$", "", body.rstrip())
    body = re.sub(r"^### 쪽 제목\s*\n+\*\*소리코지 사람들\*\*\s*\n", "", body.strip())
    body = re.sub(r"^### 1\).*\n", "", body, flags=re.M)              # 디자이너용 묶음 이름 삭제
    body = re.sub(r"^### 2\).*$", "#### 마을 어른들", body, flags=re.M)
    body = re.sub(r"^### 3\).*\n", "", body, flags=re.M)
    body = re.sub(r"^줄 머리: \*\*(.+?)\*\*\s*$", r"#### \1", body, flags=re.M)
    body = body.replace("| 그림 | 이름 | 한 줄 |", "| 지느러미 | 이름 | 한 줄 |")
    body = tables_to_lines(body)
    (ROOT / "book" / "index.qmd").write_text("# 소리코지 사람들 {.unnumbered .helper}\n\n" + body + "\n", encoding="utf-8")
    img = "images/map.png"
    map_body = (f"![]({{{{< meta map-image >}}}})\n" if (ROOT / "book" / img).exists()
                else "::: {.art-slot}\n지도 그림이 들어갈 자리\n:::\n")
    write("front-02-map.qmd", "# 소리코지 바다 지도 {.unnumbered .helper}\n\n" + map_body)

BACK = [
    ("back-01-소리코지-탐구-노트.md", "back-01-activities.qmd"),
    ("back-02-진짜-과학-노트.md", "back-02-science.qmd"),
    ("back-03-단우의-메모-용어.md", "back-03-glossary.qmd"),
    ("back-04-단우의-이름-사전.md", "back-04-namebook.qmd"),
    ("back-05-독서토론-질문.md", "back-05-questions.qmd"),
    ("back-06-작가의-말.md", "back-06-afterword.qmd"),
]

def back():
    for src, dst in BACK:
        t = strip_comments((MATTER / src).read_text(encoding="utf-8"))
        lines = t.split("\n")
        assert lines[0].startswith("# ")
        lines[0] = lines[0] + " {.unnumbered .backmatter}"
        t = "\n".join(lines)
        t = re.sub(r"\n---\n", "\n", t)                 # 구분선은 조판에서 여백으로
        t = re.sub(r"\{\{([^}]*)\}\}", r"[[\1]]", t)     # 자리표시를 눈에 띄게(교정쇄 전용)
        write(dst, t)

def colophon():
    """판권면. 확정된 값만 적고, 미정 값은 [[ ]]로 드러낸다(교정쇄 전용 — 인쇄본에 [[ ]]가 남으면 안 됨)."""
    write("back-99-colophon.qmd", """# 판권 {.unnumbered .unlisted .colophon}

**돌고래가 말했다, 돌려줘**\\
소리코지 바다 지도 1

[[초판 1쇄 발행일]]

지은이 [[작가 이름]]\\
그린이 [[삽화가 이름]]\\
펴낸곳 에르고스피어\\
[[출판사 신고번호 · 주소 · 전자우편]]

ISBN [[종이책 ISBN — 발급 전]]\\
값 14,000원

[[AI 활용 고지 문구 — 결정 전]]

이 책에 나오는 사람, 기관, 마을, 바다 이름은 지어낸 것입니다.
""")

if __name__ == "__main__":
    if SRC.exists():
        shutil.rmtree(SRC)
    SRC.mkdir(parents=True)
    chapters(); front(); back(); colophon()
    print("synced:", sorted(p.name for p in SRC.iterdir()))
